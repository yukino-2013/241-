#!/usr/bin/env python3
"""
智能运维助手 - 工具函数模块（增强版）
基础层：CPU/内存/服务/进程监控
诊断层：自动化多步分析出结论
"""

import os
import re
import psutil
import subprocess
import platform
import time
from typing import Dict, Any, List, Optional, Union


# ══════════════════════════════════════════
# 基础层：原始数据获取
# ══════════════════════════════════════════

def get_cpu_usage() -> float:
    """
    获取CPU使用率
    返回: CPU使用率百分比（浮点数）, interval=1采样1秒
    """
    try:
        usage = psutil.cpu_percent(interval=1)
        return float(usage)
    except Exception as e:
        raise Exception(f"获取CPU使用率时出错: {str(e)}")


def get_memory_usage() -> dict:
    """
    获取内存使用情况
    返回: 包含内存使用信息的字典
    """
    try:
        mem = psutil.virtual_memory()
        used_gb = mem.used / (1024**3)
        total_gb = mem.total / (1024**3)
        percent = mem.percent

        return {
            "used_gb": round(used_gb, 2),
            "total_gb": round(total_gb, 2),
            "percent": percent,
            "available_gb": round(mem.available / (1024**3), 2),
            "free_gb": round(mem.free / (1024**3), 2),
        }
    except Exception as e:
        raise Exception(f"获取内存使用情况时出错: {str(e)}")


def check_service_status(service_name: str) -> str:
    """
    检查系统服务状态
    参数: service_name - 服务名称
    返回: 服务状态描述
    """
    try:
        system = platform.system()

        if system == "Linux":
            result = subprocess.run(
                ["systemctl", "is-active", service_name],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0 and result.stdout.strip() == "active":
                return f"服务 '{service_name}' 正在运行"
            else:
                return f"服务 '{service_name}' 未运行"
        else:
            return _check_service_by_process_name(service_name)

    except FileNotFoundError:
        return _check_service_by_process_name(service_name)
    except subprocess.TimeoutExpired:
        return f"检查服务 '{service_name}' 状态超时"
    except Exception as e:
        return f"检查服务 '{service_name}' 时出错: {str(e)}"


def _check_service_by_process_name(service_name: str) -> str:
    """基于进程名检查服务（Windows/Mac 备用方案）"""
    try:
        for proc in psutil.process_iter(['name']):
            try:
                proc_name = proc.info['name'].lower()
                if service_name.lower() in proc_name:
                    return f"服务 '{service_name}' 正在运行（通过进程名检测）"
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return f"服务 '{service_name}' 未运行（未找到相关进程）"
    except Exception as e:
        return f"检查服务时出错: {str(e)}"


# ══════════════════════════════════════════
# 进程分析工具
# ══════════════════════════════════════════

def get_top_processes(cpu_or_memory: str = "cpu", limit: int = 5) -> List[Dict]:
    """
    获取占用资源最多的进程（来自用户设计）
    参数:
        cpu_or_memory: "cpu" 或 "memory"
        limit: 返回前N个进程
    返回: 进程列表，每项含 pid, name, cpu_percent, memory_percent
    """
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'memory_percent']):
        try:
            # cpu_percent 用非阻塞模式获取
            cpu_pct = proc.cpu_percent(interval=0)
            info = {
                "pid": proc.info['pid'],
                "name": proc.info['name'],
                "cpu_percent": round(cpu_pct, 1),
                "memory_percent": round(proc.info['memory_percent'] or 0, 1),
            }
            processes.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if not processes:
        return []

    if cpu_or_memory == "cpu":
        processes.sort(key=lambda x: x['cpu_percent'], reverse=True)
    else:
        processes.sort(key=lambda x: x['memory_percent'], reverse=True)

    return processes[:limit]


def get_process_details(pid: int) -> Dict[str, Any]:
    """
    获取特定进程的详细信息（来自用户设计）
    参数: pid - 进程ID
    返回: 进程详细信息（异常信息会被过滤，避免AI输出过于冗长）
    """
    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return {"error": f"进程 {pid} 不存在"}
    except psutil.AccessDenied:
        return {"error": f"无权限访问进程 {pid}"}

    details = {
        "pid": pid,
        "name": proc.name(),
        "status": proc.status(),
        "cpu_percent": round(proc.cpu_percent(interval=0), 1),
        "memory_percent": round(proc.memory_percent(), 1),
        "memory_rss_mb": round(proc.memory_info().rss / (1024**2), 1),
        "threads": proc.num_threads(),
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(proc.create_time())),
    }

    # 安全获取 command line
    try:
        cmdline = proc.cmdline()
        details["cmdline"] = " ".join(cmdline) if cmdline else "N/A"
    except (psutil.AccessDenied, Exception):
        details["cmdline"] = "N/A"

    # 只对 CPU/内存占用高的进程才获取连接和文件信息
    is_high_resource = (
        details["cpu_percent"] > 20 or details["memory_percent"] > 10
    )
    if is_high_resource:
        try:
            conns = proc.connections()
            details["connections_count"] = len(conns)
            if conns:
                # 只统计不同类型的连接数，不列出每条
                listening = sum(1 for c in conns if c.status == "LISTEN")
                established = sum(1 for c in conns if c.status == "ESTABLISHED")
                details["connections_summary"] = {
                    "listening": listening,
                    "established": established,
                    "total": len(conns)
                }
        except (psutil.AccessDenied, Exception):
            details["connections"] = "N/A（无权限）"

        try:
            files = proc.open_files()
            details["open_files_count"] = len(files)
        except (psutil.AccessDenied, Exception):
            details["open_files"] = "N/A（无权限）"

    return details


# ══════════════════════════════════════════
# P0 工具：网络诊断
# ══════════════════════════════════════════

def check_network_connectivity(host: str = "8.8.8.8", count: int = 3) -> Dict[str, Any]:
    """
    检查网络连通性（ping 测试）
    参数:
        host: 目标主机（默认8.8.8.8）
        count: ping包数量（默认3）
    返回: 连通性报告
    """
    result = {"host": host, "reachable": False, "packet_loss": 100, "avg_latency_ms": None}

    try:
        system = platform.system()
        if system == "Windows":
            cmd = ["ping", "-n", str(count), host]
        else:
            cmd = ["ping", "-c", str(count), host]

        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        output = (proc.stdout + proc.stderr).lower()

        # 解析结果
        if proc.returncode == 0:
            result["reachable"] = True

        # 尝试解析丢包率
        import re
        loss_match = re.search(r"(\d+)%", output)
        if loss_match:
            result["packet_loss"] = int(loss_match.group(1))

        # 尝试解析延迟
        avg_match = re.search(r"(平均|avg|rtt)\s*[=:]\s*(\d+\.?\d*)", output)
        if avg_match:
            result["avg_latency_ms"] = float(avg_match.group(2))

        result["_raw_exit_code"] = proc.returncode

    except subprocess.TimeoutExpired:
        result["error"] = "ping 超时"
    except FileNotFoundError:
        result["error"] = "ping 命令不可用"
    except Exception as e:
        result["error"] = str(e)

    return result


def check_port_listening(port: int, protocol: str = "tcp") -> Dict[str, Any]:
    """
    检查端口是否在监听
    参数:
        port: 端口号
        protocol: "tcp" 或 "udp"
    返回: 端口状态
    """
    result = {"port": port, "protocol": protocol, "listening": False, "process": None}

    try:
        conn_type = "tcp" if protocol == "tcp" else "udp4" if protocol == "udp" else protocol
        for conn in psutil.net_connections(kind=conn_type):
            if conn.status == "LISTEN" and conn.laddr.port == port:
                result["listening"] = True
                try:
                    proc = psutil.Process(conn.pid)
                    result["process"] = {
                        "pid": conn.pid,
                        "name": proc.name(),
                        "cmdline": " ".join(proc.cmdline())[:100] if proc.cmdline() else "N/A",
                    }
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    result["process"] = {"pid": conn.pid, "name": "N/A"}
                break
    except psutil.AccessDenied:
        result["error"] = "需要管理员权限查看端口信息"
    except Exception as e:
        result["error"] = str(e)

    return result


def get_network_summary() -> Dict[str, Any]:
    """
    获取网络连接概览
    返回: 各状态连接数、监听端口列表
    """
    summary = {"total_connections": 0, "by_status": {}, "listening_ports": []}

    try:
        conns = psutil.net_connections()
        summary["total_connections"] = len(conns)

        for conn in conns:
            status = conn.status if conn.status else "NONE"
            summary["by_status"][status] = summary["by_status"].get(status, 0) + 1

            if status == "LISTEN":
                summary["listening_ports"].append({
                    "port": conn.laddr.port,
                    "pid": conn.pid,
                })

        summary["listening_ports"].sort(key=lambda x: x["port"])

    except psutil.AccessDenied:
        summary["error"] = "需要管理员权限"
    except Exception as e:
        summary["error"] = str(e)

    return summary


# ══════════════════════════════════════════
# P0 工具：磁盘分析
# ══════════════════════════════════════════

def get_disk_usage() -> List[Dict[str, Any]]:
    """
    获取所有分区的磁盘使用情况
    返回: 每个分区的使用详情列表
    """
    partitions = []
    for part in psutil.disk_partitions():
        try:
            usage = psutil.disk_usage(part.mountpoint)
            partitions.append({
                "device": part.device,
                "mountpoint": part.mountpoint,
                "fstype": part.fstype,
                "total_gb": round(usage.total / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "free_gb": round(usage.free / (1024**3), 2),
                "percent": usage.percent,
            })
        except (PermissionError, OSError):
            continue

    return partitions


def get_disk_io() -> Dict[str, Any]:
    """
    获取磁盘 I/O 统计信息（读写速率）
    返回: 磁盘 I/O 概览
    """
    try:
        io = psutil.disk_io_counters(perdisk=False)
        return {
            "total_read_mb": round(io.read_bytes / (1024**2), 2),
            "total_write_mb": round(io.write_bytes / (1024**2), 2),
            "read_count": io.read_count,
            "write_count": io.write_count,
            "read_time_ms": io.read_time,
            "write_time_ms": io.write_time,
        }
    except Exception as e:
        return {"error": str(e)}


# ══════════════════════════════════════════
# P0 工具：日志搜索
# ══════════════════════════════════════════

def search_system_logs(keywords: str = "", lines: int = 30) -> str:
    """
    搜索系统日志
    参数:
        keywords: 关键词（选填，空=返回最近日志）
        lines: 返回行数（默认30）
    返回: 日志文本
    """
    system = platform.system()

    try:
        if system == "Linux":
            if keywords:
                cmd = f"journalctl -n {lines} --no-pager | grep -i '{keywords}' || echo '无匹配'"
            else:
                cmd = f"journalctl -n {lines} --no-pager"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            output = result.stdout or result.stderr
            return output.strip() or "无日志输出"
        elif system == "Windows":
            # Windows上用PowerShell获取事件日志
            if keywords:
                cmd = f"Get-EventLog -LogName System -Newest {lines} | Where-Object {{ $_.Message -like '*{keywords}*' }} | Format-Table TimeGenerated, EntryType, Message -AutoSize -Wrap"
            else:
                cmd = f"Get-EventLog -LogName System -Newest {lines} | Format-Table TimeGenerated, EntryType, Message -AutoSize -Wrap"
            result = subprocess.run(
                ["powershell", "-Command", cmd],
                capture_output=True, text=True, timeout=15
            )
            return result.stdout.strip() or "无日志输出"
        else:
            return f"不支持的系统: {system}"
    except subprocess.TimeoutExpired:
        return "日志查询超时"
    except Exception as e:
        return f"日志查询失败: {e}"

def _severity_label(level: str) -> str:
    """生成严重性标签"""
    labels = {
        "info": "[INFO]",
        "warn": "[WARNING]",
        "critical": "[CRITICAL]",
    }
    return labels.get(level, "[INFO]")


def diagnose_cpu_spike() -> Dict[str, Any]:
    """
    CPU异常诊断 — 自动分析哪个进程占用高、原因是什么
    返回结构化诊断报告
    """
    report = {
        "check": "CPU 异常诊断",
        "severity": "info",
        "findings": [],
        "conclusion": "",
        "recommendation": "",
    }

    # 1. 整体CPU使用率
    try:
        cpu_pct = psutil.cpu_percent(interval=1)
        report["cpu_total"] = cpu_pct

        if cpu_pct < 50:
            report["severity"] = "info"
            report["conclusion"] = f"CPU 使用率 {cpu_pct}%，在正常范围内。"
            return report
        elif cpu_pct < 80:
            report["severity"] = "warn"
            report["findings"].append(f"CPU 使用率 {cpu_pct}%，偏高。")
        else:
            report["severity"] = "critical"
            report["findings"].append(f"CPU 使用率 {cpu_pct}%，严重偏高！")
    except Exception as e:
        report["findings"].append(f"获取CPU使用率失败: {e}")
        report["severity"] = "warn"
        return report

    # 2. 找出最耗CPU的进程
    try:
        top_procs = get_top_processes("cpu", 5)
        if not top_procs:
            report["findings"].append("无法获取进程列表。")
            return report

        report["top_processes"] = top_procs
        culprit = top_procs[0]

        report["findings"].append(
            f"占用最高进程: {culprit['name']}(PID={culprit['pid']}), "
            f"CPU={culprit['cpu_percent']}%, 内存={culprit['memory_percent']}%"
        )

        # 3. 深入分析嫌疑进程
        if culprit["cpu_percent"] > 30:
            details = get_process_details(culprit["pid"])
            if "error" not in details:
                # 判断可疑点
                suspicious = []
                if culprit["name"].lower() in ("java", "python", "node"):
                    suspicious.append(f"{culprit['name']} 进程 CPU 过高，常见原因是资源泄漏或代码死循环")

                conn_count = details.get("connections_summary", {}).get("total", 0)
                if conn_count > 200:
                    suspicious.append(f"连接数高达 {conn_count}，可能是流量洪峰或 DDoS")

                threads = details.get("threads", 0)
                if threads > 500:
                    suspicious.append(f"线程数 {threads} 过多，可能有线程泄漏")

                if suspicious:
                    report["findings"].append("可疑发现:")
                    for s in suspicious:
                        report["findings"].append(f"  - {s}")
                else:
                    report["findings"].append("未发现明显异常模式，建议查看应用日志。")

        # 4. 给出结论
        report["conclusion"] = (
            f"CPU 使用率 {cpu_pct}%，主要被 {culprit['name']}(PID={culprit['pid']}) 占用 "
            f"({culprit['cpu_percent']}%)"
        )

        report["recommendation"] = (
            f"建议: 检查 {culprit['name']} 的应用日志和配置，"
            f"如果是偶发现象可重启该进程，持续异常则需代码层面排查。"
        )

    except Exception as e:
        report["findings"].append(f"深度诊断失败: {e}")

    return report


def diagnose_memory_pressure() -> Dict[str, Any]:
    """
    内存压力诊断 — 自动分析内存使用是否异常、哪些进程在吃内存
    返回结构化诊断报告
    """
    report = {
        "check": "内存压力诊断",
        "severity": "info",
        "findings": [],
        "conclusion": "",
        "recommendation": "",
    }

    try:
        mem = psutil.virtual_memory()
        mem_pct = mem.percent
        used_gb = mem.used / (1024**3)
        total_gb = mem.total / (1024**3)
        available_gb = mem.available / (1024**3)

        report["memory_total_gb"] = round(total_gb, 2)
        report["memory_used_gb"] = round(used_gb, 2)
        report["memory_percent"] = mem_pct
        report["available_gb"] = round(available_gb, 2)

        if mem_pct < 60:
            report["severity"] = "info"
            report["conclusion"] = f"内存使用率 {mem_pct}%，状态良好。"
            return report
        elif mem_pct < 80:
            report["severity"] = "warn"
            report["findings"].append(f"内存使用率 {mem_pct}%（{round(used_gb,1)}GB/{round(total_gb,1)}GB），偏高。")
        else:
            report["severity"] = "critical"
            report["findings"].append(f"内存使用率 {mem_pct}%（{round(used_gb,1)}GB/{round(total_gb,1)}GB），严重不足！")

        # 找出最耗内存的进程
        top_procs = get_top_processes("memory", 5)
        report["top_processes"] = top_procs

        if top_procs:
            total_by_top = sum(p["memory_percent"] for p in top_procs)
            report["findings"].append(f"前5大内存消耗进程占总内存 {round(total_by_top,1)}%")

            culprit = top_procs[0]
            report["findings"].append(
                f"最大消耗者: {culprit['name']}(PID={culprit['pid']}), "
                f"内存={culprit['memory_percent']}%, CPU={culprit['cpu_percent']}%"
            )

            # 判断可疑点
            if culprit['memory_percent'] > 20:
                details = get_process_details(culprit["pid"])
                if "error" not in details:
                    rss = details.get("memory_rss_mb", 0)
                    report["findings"].append(
                        f"{culprit['name']} 占用了 {rss}MB 物理内存"
                    )

        # 检查 swap 使用
        try:
            swap = psutil.swap_memory()
            if swap.total > 0:
                swap_pct = swap.percent
                report["swap_percent"] = swap_pct
                if swap_pct > 30:
                    report["findings"].append(
                        f"Swap 使用率 {swap_pct}%，大量使用 swap 说明物理内存严重不足"
                    )
        except Exception:
            pass

        total_findings = len(report["findings"])
        report["conclusion"] = (
            f"内存使用率 {mem_pct}%，可用 {round(available_gb,1)}GB/{round(total_gb,1)}GB。"
            f"发现 {total_findings} 个值得关注的点。"
        )

        if mem_pct > 80:
            report["recommendation"] = (
                "建议: 1)关闭不需要的进程释放内存 2)检查是否有内存泄漏 "
                "3)考虑增加物理内存或配置 swap"
            )

    except Exception as e:
        report["findings"].append(f"内存诊断失败: {e}")
        report["severity"] = "warn"

    return report


def diagnose_service_fault(service_name: str) -> Dict[str, Any]:
    """
    服务故障诊断 — 检查服务状态、尝试分析故障原因
    返回结构化诊断报告
    """
    report = {
        "check": f"服务 '{service_name}' 故障诊断",
        "severity": "info",
        "findings": [],
        "conclusion": "",
        "recommendation": "",
    }

    try:
        status = check_service_status(service_name)
        report["service_status"] = status

        if "正在运行" in status:
            report["severity"] = "info"
            report["conclusion"] = f"服务 '{service_name}' 运行正常。"
            return report

        report["findings"].append(status)
        report["severity"] = "critical"

        # 尝试找该服务的进程
        found = False
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                name = proc.info['name'].lower() if proc.info['name'] else ""
                cmd = " ".join(proc.info['cmdline']).lower() if proc.info['cmdline'] else ""
                if service_name.lower() in name or service_name.lower() in cmd:
                    found = True
                    report["findings"].append(
                        f"发现相关进程: {proc.info['name']}(PID={proc.info['pid']})"
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if not found:
            report["findings"].append(f"未找到 {service_name} 的任何相关进程。")

        # 端口检查（常见服务）
        port_map = {
            "nginx": [80, 443],
            "mysql": [3306],
            "redis": [6379],
            "ssh": [22],
            "sshd": [22],
        }
        if service_name.lower() in port_map:
            ports = port_map[service_name.lower()]
            listening_ports = []
            try:
                for conn in psutil.net_connections():
                    if conn.status == "LISTEN" and conn.laddr.port in ports:
                        listening_ports.append(conn.laddr.port)
            except (psutil.AccessDenied, Exception) as e:
                report["findings"].append(f"端口检查需要管理员权限: {e}")

            if listening_ports:
                report["findings"].append(
                    f"检测到端口 {listening_ports} 处于监听状态，"
                    f"说明服务可能已启动但未注册到 systemd。"
                )
            else:
                report["findings"].append(
                    f"端口 {ports} 均未被监听，服务确实未启动。"
                )

        report["conclusion"] = f"服务 '{service_name}' 未正常运行。"
        report["recommendation"] = (
            f"建议: 1)检查配置文件语法: sudo {service_name} -t "
            f"2)查看日志: journalctl -u {service_name} -n 50 "
            f"3)尝试启动: sudo systemctl start {service_name}"
        )

    except Exception as e:
        report["findings"].append(f"诊断失败: {e}")
        report["severity"] = "warn"

    return report


# ══════════════════════════════════════════
# 测试
# ══════════════════════════════════════════

def test_tools():
    """测试所有工具函数"""
    print("=" * 60)
    print("测试工具函数（增强版）")
    print("=" * 60)

    # 1. CPU
    print("\n1. CPU 使用率:")
    print(f"   {get_cpu_usage()}%")

    # 2. 内存
    print("\n2. 内存使用情况:")
    mem = get_memory_usage()
    print(f"   {mem['used_gb']}GB/{mem['total_gb']}GB ({mem['percent']}%)")

    # 3. Top 进程
    print("\n3. Top 进程（按CPU）:")
    for p in get_top_processes("cpu", 5):
        print(f"   {p['name']}(PID={p['pid']}) CPU={p['cpu_percent']}% MEM={p['memory_percent']}%")

    # 4. Top 进程（按内存）
    print("\n4. Top 进程（按内存）:")
    for p in get_top_processes("memory", 5):
        print(f"   {p['name']}(PID={p['pid']}) CPU={p['cpu_percent']}% MEM={p['memory_percent']}%")

    # 5. 进程详情（取第一个有CPU的）
    print("\n5. 进程详情:")
    top = get_top_processes("cpu", 1)
    if top:
        details = get_process_details(top[0]["pid"])
        for k, v in details.items():
            print(f"   {k}: {v}")

    # 6. CPU 诊断
    print("\n6. CPU 异常诊断:")
    cpu_diag = diagnose_cpu_spike()
    print(f"   严重性: {cpu_diag['severity']}")
    for f in cpu_diag["findings"]:
        print(f"   > {f}")
    print(f"   结论: {cpu_diag['conclusion'][:80]}...")

    # 7. 内存诊断
    print("\n7. 内存压力诊断:")
    mem_diag = diagnose_memory_pressure()
    print(f"   严重性: {mem_diag['severity']}")
    for f in mem_diag["findings"][:3]:
        print(f"   > {f}")

    print("\n" + "=" * 60)
    print("测试完成！")


if __name__ == "__main__":
    test_tools()
