#!/usr/bin/env python3
"""
智能运维助手 - DeepAgents 智能体（最终版）
基于 DeepAgents 框架 + 智谱AI GLM-4
内置: TodoList(任务规划) + LocalShellBackend(Shell执行) + SubAgent(子代理) + 对话记忆
"""

import os
import sys
import threading
import time
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

# DeepAgents 框架
from deepagents import create_deep_agent
from deepagents.backends import LocalShellBackend

# LangChain 核心组件（DeepAgents 底层依赖）
from langchain_openai import ChatOpenAI
from langchain.tools import tool as langchain_tool
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.checkpoint.memory import InMemorySaver

# 加载环境变量
load_dotenv()


# ──────────────────────────────────────────
# 导入工具函数
# ──────────────────────────────────────────
def import_tools():
    """动态导入tools模块，处理不同位置的导入"""
    try:
        from tools import get_cpu_usage, get_memory_usage, check_service_status
        return get_cpu_usage, get_memory_usage, check_service_status
    except ImportError:
        backend_path = os.path.join(os.path.dirname(__file__))
        if backend_path not in sys.path:
            sys.path.insert(0, backend_path)
        try:
            from tools import get_cpu_usage, get_memory_usage, check_service_status
            return get_cpu_usage, get_memory_usage, check_service_status
        except ImportError as e:
            raise ImportError(f"无法导入tools模块: {e}. 请确保tools.py文件在backend目录中")

get_cpu_usage, get_memory_usage, check_service_status = import_tools()


# ──────────────────────────────────────────
# 自定义监测工具
# ──────────────────────────────────────────
@langchain_tool
def get_cpu_usage_tool() -> str:
    """获取当前CPU使用率。当用户询问CPU使用情况、电脑卡不卡、系统负载时调用此工具。"""
    try:
        cpu_usage = get_cpu_usage()
        return f"当前CPU使用率为: {cpu_usage:.1f}%"
    except Exception as e:
        return f"获取CPU使用率失败: {str(e)}"


@langchain_tool
def get_memory_usage_tool() -> str:
    """获取当前内存使用情况。当用户询问内存够不够、内存使用率、剩余内存时调用此工具。"""
    try:
        memory_info = get_memory_usage()
        return f"内存已使用{memory_info['used_gb']:.1f}GB/共{memory_info['total_gb']:.1f}GB，使用率{memory_info['percent']:.1f}%"
    except Exception as e:
        return f"获取内存使用率失败: {str(e)}"


@langchain_tool
def check_service_status_tool(service_name: str) -> str:
    """检查某个系统服务是否在运行。输入参数应为服务名称（如nginx、sshd、mysql、python）。当用户询问某个服务是否运行、服务状态时调用此工具。"""
    try:
        status = check_service_status(service_name)
        return f"服务 {service_name} 状态: {status}"
    except Exception as e:
        return f"检查服务状态失败: {str(e)}"


@langchain_tool
def get_system_info_tool() -> str:
    """获取完整的系统信息，包括操作系统、主机名、Python版本等。"""
    try:
        import platform
        import socket
        import datetime
        
        info = []
        info.append(f"系统: {platform.system()} {platform.release()}")
        info.append(f"主机名: {socket.gethostname()}")
        info.append(f"Python版本: {platform.python_version()}")
        info.append(f"当前时间: {datetime.datetime.now()}")
        info.append(f"AI模型: 智谱GLM-4")
        
        return "\n".join(info)
    except Exception as e:
        return f"获取系统信息失败: {str(e)}"


@langchain_tool
def analyze_system_health_tool() -> Dict[str, Any]:
    """分析系统健康状况，包括CPU、内存、磁盘的综合评估。"""
    try:
        import psutil
        
        cpu_percent = get_cpu_usage()
        memory_info = get_memory_usage()
        
        health_report = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "cpu_usage": cpu_percent,
            "memory_usage": memory_info["percent"],
            "memory_details": memory_info,
            "disk_usage": {},
            "overall_health": "良好"
        }
        
        # 检查磁盘使用
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                health_report["disk_usage"][partition.mountpoint] = {
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "free_gb": round(usage.free / (1024**3), 2),
                    "percent": usage.percent
                }
            except:
                pass
        
        # 健康评估
        if cpu_percent > 90:
            health_report["overall_health"] = "警告"
        elif cpu_percent > 80:
            health_report["overall_health"] = "注意"
            
        if memory_info["percent"] > 90:
            health_report["overall_health"] = "警告"
        elif memory_info["percent"] > 80:
            if health_report["overall_health"] != "警告":
                health_report["overall_health"] = "注意"
        
        return health_report
    except Exception as e:
        return {"error": f"分析系统健康失败: {str(e)}"}


# ══════════════════════════════════════════
# 进程分析工具
# ══════════════════════════════════════════

@langchain_tool
def get_top_processes_tool(cpu_or_memory: str = "cpu", limit: int = 5) -> str:
    """获取占用资源最多的进程。参数: cpu_or_memory为"cpu"或"memory"，limit为返回个数。"""
    try:
        from tools import get_top_processes
        procs = get_top_processes(cpu_or_memory, limit)
        if not procs:
            return "无法获取进程信息"
        result = [f"Top {len(procs)} 进程（按{ 'CPU' if cpu_or_memory=='cpu' else '内存' }）:"]
        for p in procs:
            result.append(f"  {p['name']}(PID={p['pid']}) CPU={p['cpu_percent']}% MEM={p['memory_percent']}%")
        return "\n".join(result)
    except Exception as e:
        return f"获取进程信息失败: {str(e)}"


@langchain_tool
def get_process_details_tool(pid: int) -> str:
    """获取某个进程的详细信息。输入参数为进程PID。"""
    try:
        from tools import get_process_details
        details = get_process_details(pid)
        if "error" in details:
            return details["error"]
        lines = [f"进程 {pid} 详细信息:"]
        for k, v in details.items():
            if k == "connections_summary" and isinstance(v, dict):
                lines.append(f"  连接: 监听{v['listening']}个 ESTABLISHED{v['established']}个 共{v['total']}个")
            else:
                lines.append(f"  {k}: {v}")
        return "\n".join(lines)
    except Exception as e:
        return f"获取进程详情失败: {str(e)}"


# ══════════════════════════════════════════
# P0 工具：网络诊断
# ══════════════════════════════════════════

@langchain_tool
def check_network_connectivity_tool(host: str = "8.8.8.8", count: int = 3) -> str:
    """检查网络连通性（ping）。参数: host为目标主机地址，count为ping包数量。"""
    try:
        from tools import check_network_connectivity
        result = check_network_connectivity(host, count)

        if result.get("reachable"):
            latency = result.get("avg_latency_ms", "N/A")
            loss = result.get("packet_loss", "N/A")
            return f"✅ {host} 可达 | 延迟={latency}ms | 丢包={loss}%"
        else:
            err = result.get("error", "无法连通")
            return f"❌ {host} 不可达: {err}"
    except Exception as e:
        return f"网络连通性检查失败: {e}"


@langchain_tool
def check_port_listening_tool(port: int) -> str:
    """检查端口是否在监听。参数: port为端口号。"""
    try:
        from tools import check_port_listening
        result = check_port_listening(port)

        if result["listening"]:
            proc = result.get("process", {})
            info = f"端口 {port} 正在监听"
            if proc and proc.get("name"):
                info += f" (进程: {proc['name']}, PID={proc['pid']})"
            return info
        else:
            err = result.get("error", "未被监听")
            return f"端口 {port} 未被监听" + (f" ({err})" if "error" in result else "")
    except Exception as e:
        return f"端口检查失败: {e}"


@langchain_tool
def get_network_summary_tool() -> str:
    """获取网络连接概览，包括各状态的连接数量和监听端口列表。"""
    try:
        from tools import get_network_summary
        summary = get_network_summary()

        if "error" in summary:
            return f"获取网络概览失败: {summary['error']}"

        lines = [f"网络连接概览 (共{summary['total_connections']}条)"]
        for status, count in sorted(summary["by_status"].items()):
            lines.append(f"  {status}: {count}")

        ports = summary.get("listening_ports", [])
        if ports:
            port_text = ", ".join(f"{p['port']}" for p in ports[:20])
            lines.append(f"  监听端口 ({len(ports)}个): {port_text}")

        return "\n".join(lines)
    except Exception as e:
        return f"获取网络概览失败: {e}"


# ══════════════════════════════════════════
# P0 工具：磁盘分析
# ══════════════════════════════════════════

@langchain_tool
def check_disk_usage_tool() -> str:
    """获取所有磁盘分区的使用情况。"""
    try:
        from tools import get_disk_usage
        partitions = get_disk_usage()
        if not partitions:
            return "无法获取磁盘信息"

        lines = ["磁盘使用情况:"]
        for p in partitions:
            lines.append(
                f"  {p['mountpoint']} ({p['fstype']}): "
                f"{p['used_gb']}GB/{p['total_gb']}GB ({p['percent']}%)"
            )
        return "\n".join(lines)
    except Exception as e:
        return f"获取磁盘使用情况失败: {e}"


@langchain_tool
def check_disk_io_tool() -> str:
    """获取磁盘I/O统计信息（读写量）。"""
    try:
        from tools import get_disk_io
        io = get_disk_io()
        if "error" in io:
            return f"获取磁盘I/O失败: {io['error']}"
        return (
            f"磁盘I/O: 读取{io['total_read_mb']}MB | "
            f"写入{io['total_write_mb']}MB | "
            f"读次数{io['read_count']} | 写次数{io['write_count']}"
        )
    except Exception as e:
        return f"获取磁盘I/O失败: {e}"


# ══════════════════════════════════════════
# P0 工具：日志查询
# ══════════════════════════════════════════

@langchain_tool
def search_system_logs_tool(keywords: str = "", lines: int = 30) -> str:
    """搜索系统日志。参数: keywords为关键词(可选)，lines为返回行数。"""
    try:
        from tools import search_system_logs
        result = search_system_logs(keywords, lines)
        if keywords:
            return f"日志搜索结果（关键词: {keywords}）:\n{result[:2000]}"
        else:
            return f"最近系统日志:\n{result[:2000]}"
    except Exception as e:
        return f"日志查询失败: {e}"


# ══════════════════════════════════════════
# 诊断层工具——自动化多步分析出结论
# ══════════════════════════════════════════

@langchain_tool
def diagnose_cpu_spike_tool() -> str:
    """【诊断工具】CPU异常深度诊断。检测到CPU偏高时调用此工具，会自动分析占用最高的进程及其原因。"""
    try:
        from tools import diagnose_cpu_spike
        report = diagnose_cpu_spike()

        severity_tag = {"info": "✅", "warn": "⚡", "critical": "🚨"}
        tag = severity_tag.get(report["severity"], "ℹ️")

        lines = [f"{tag} CPU诊断 ({report['severity'].upper()})"]
        for finding in report["findings"]:
            lines.append(f"  {finding}")

        if report.get("top_processes"):
            lines.append("  Top进程:")
            for p in report["top_processes"]:
                lines.append(f"    {p['name']}(PID={p['pid']}) CPU={p['cpu_percent']}%")

        lines.append(f"  结论: {report['conclusion']}")
        if report["recommendation"]:
            lines.append(f"  建议: {report['recommendation']}")

        return "\n".join(lines)
    except Exception as e:
        return f"CPU诊断失败: {str(e)}"


@langchain_tool
def diagnose_memory_pressure_tool() -> str:
    """【诊断工具】内存压力诊断。检测到内存不足时调用此工具，会自动分析内存消耗来源和泄漏风险。"""
    try:
        from tools import diagnose_memory_pressure
        report = diagnose_memory_pressure()

        severity_tag = {"info": "✅", "warn": "⚡", "critical": "🚨"}
        tag = severity_tag.get(report["severity"], "ℹ️")

        lines = [f"{tag} 内存诊断 ({report['severity'].upper()})"]
        lines.append(f"  内存: {report.get('memory_used_gb','?')}GB/{report.get('memory_total_gb','?')}GB ({report.get('memory_percent','?')}%)")

        for finding in report["findings"]:
            lines.append(f"  {finding}")

        lines.append(f"  结论: {report['conclusion']}")
        if report["recommendation"]:
            lines.append(f"  建议: {report['recommendation']}")

        return "\n".join(lines)
    except Exception as e:
        return f"内存诊断失败: {str(e)}"


@langchain_tool
def diagnose_service_fault_tool(service_name: str) -> str:
    """【诊断工具】服务故障诊断。当服务状态异常时调用此工具，会自动检查进程、端口、配置等综合分析原因。"""
    try:
        from tools import diagnose_service_fault
        report = diagnose_service_fault(service_name)

        severity_tag = {"info": "✅", "warn": "⚡", "critical": "🚨"}
        tag = severity_tag.get(report["severity"], "ℹ️")

        lines = [f"{tag} 服务诊断: {service_name} ({report['severity'].upper()})"]
        for finding in report["findings"]:
            lines.append(f"  {finding}")

        lines.append(f"  结论: {report['conclusion']}")
        if report["recommendation"]:
            lines.append(f"  建议: {report['recommendation']}")

        return "\n".join(lines)
    except Exception as e:
        return f"服务诊断失败: {str(e)}"


# ══════════════════════════════════════════
# 知识库工具
# ══════════════════════════════════════════

@langchain_tool
def query_knowledge_base_tool(query: str) -> str:
    """查询知识库，获取历史诊断记录、服务器基线信息。每次排障前都先调用此工具查一下。参数: query为问题描述或关键词。"""
    try:
        from knowledge_base import query_knowledge
        result = query_knowledge(query, limit=5)
        lines = []

        if result["baselines"]:
            lines.append("[基线数据]")
            for b in result["baselines"][:8]:
                lines.append(f"  {b['metric']}: {b['value']}{b['unit']}")

        if result["diagnoses"]:
            lines.append("[历史诊断]")
            for d in result["diagnoses"][:3]:
                lines.append(f"  [{d['severity']}] {d['symptom']}: {d['diagnosis'][:80]}")
                if d['resolution']:
                    lines.append(f"  解决: {d['resolution'][:60]}")

        if result["knowledge"]:
            lines.append("[参考知识]")
            for k in result["knowledge"][:3]:
                lines.append(f"  {k['topic']}: {k['content'][:100]}")

        if not lines:
            return f"知识库中未找到相关记录。排障完成后记得保存经验。"

        return "\n".join(lines)
    except Exception as e:
        return f"查询知识库失败: {e}"


@langchain_tool
def remember_knowledge_tool(topic: str, content: str) -> str:
    """保存一条知识或经验到知识库。参数: topic为主题，content为详细内容。"""
    try:
        from knowledge_base import add_knowledge
        result = add_knowledge(topic, content)
        return f"[OK] 知识已保存: [{topic}]"
    except Exception as e:
        return f"保存知识失败: {e}"


@langchain_tool
def record_diagnosis_tool(symptom: str, diagnosis: str, resolution: str = "", service: str = "", severity: str = "info") -> str:
    """记录一次排障结果到知识库。每次排障完成后调用。参数: symptom症状, diagnosis诊断, resolution解决方案, service相关服务。"""
    try:
        from knowledge_base import store_diagnosis
        result = store_diagnosis(symptom, diagnosis, resolution, service, severity)
        return f"[OK] 排障记录已保存 (id={result['id']})"
    except Exception as e:
        return f"保存排障记录失败: {e}"


# ══════════════════════════════════════════
# 智能体主类
# ══════════════════════════════════════════
class OpsAgent:
    """DeepAgents 智能运维助手（单例）"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls, show_init_info: bool = True):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
        return cls._instance

    def __init__(self, show_init_info: bool = True):
        if self._initialized:
            return

        self.show_init_info = show_init_info
        self.agent = None
        self.checkpointer = None
        self.backend = None
        self.thread_id = "default_session"

        try:
            self._initialize_components()
            self._initialized = True

            if self.show_init_info:
                print("[INFO] DeepAgents 智能运维助手初始化完成")
                print(f"   • 智能体模式: {self.agent_type}")
                print(f"   • 自定义工具: {len(self.tools)}个")
                print("   • DeepAgents 内置: TodoList + Shell执行 + 子代理 + 文件系统")
                print(f"   • 对话记忆: [OK]")
        except Exception as e:
            print(f"[ERROR] 初始化智能体失败: {e}")
            raise

    def _initialize_components(self):
        """初始化所有组件"""
        # 1. 配置智谱AI
        api_key = os.getenv("ZHIPUAI_API_KEY")
        if not api_key:
            raise ValueError("请先在.env文件中配置ZHIPUAI_API_KEY")

        model_name = os.getenv("ZHIPUAI_MODEL", "glm-4")
        base_url = "https://open.bigmodel.cn/api/paas/v4"

        # 2. 初始化聊天模型
        self.model = ChatOpenAI(
            model=model_name,
            openai_api_key=api_key,
            base_url=base_url,
            temperature=0.3,
            max_tokens=2000
        )

        # 3. 准备自定义工具列表（19个 + 1个内置execute）
        self.tools = [
            # 基础监测（5）
            get_cpu_usage_tool,
            get_memory_usage_tool,
            check_service_status_tool,
            get_system_info_tool,
            analyze_system_health_tool,
            # 进程分析（2）
            get_top_processes_tool,
            get_process_details_tool,
            # P0 网络诊断（3）
            check_network_connectivity_tool,
            check_port_listening_tool,
            get_network_summary_tool,
            # P0 磁盘分析（2）
            check_disk_usage_tool,
            check_disk_io_tool,
            # P0 日志查询（1）
            search_system_logs_tool,
            # 深度诊断（3）
            diagnose_cpu_spike_tool,
            diagnose_memory_pressure_tool,
            diagnose_service_fault_tool,
            # 知识库（3）
            query_knowledge_base_tool,
            remember_knowledge_tool,
            record_diagnosis_tool,
        ]

        # 4. 创建检查点保存器（对话记忆）
        self.checkpointer = InMemorySaver()

        # 5. 创建沙箱目录（execute 工具的默认工作目录）
        sandbox_dir = Path(__file__).resolve().parent / "agent_sandbox"
        sandbox_dir.mkdir(exist_ok=True)

        # 6. 创建 Shell 执行后端（沙箱模式）
        self.backend = LocalShellBackend(
            root_dir=str(sandbox_dir),
            virtual_mode=True,
            timeout=30,
            inherit_env=True,
        )

        # 7. 初始化知识库（自动采集基线）
        try:
            from knowledge_base import ensure_kb_ready
            ensure_kb_ready()
            self.knowledge_base_ready = True
            self.tools_count_extra = 3  # 3个知识库工具
        except Exception as e:
            print(f"[WARN] 知识库初始化失败: {e}")
            self.knowledge_base_ready = False

        # 8. 系统提示词 — SRE 角色定位（v4：知识库加持）
        system_prompt = """## 角色定位
你是一个资深 SRE，拥有 10 年以上的系统运维经验。

## 自定义工具（19个）
① 基础监测(5): cpu / memory / service / system_info / analyze_health
② 进程分析(2): top_processes / process_details
③ 网络诊断(3): network_connectivity / port_check / network_summary
④ 磁盘分析(2): disk_usage / disk_io
⑤ 日志查询(1): search_logs
⑥ 快捷诊断(3): diagnose_cpu / diagnose_memory / diagnose_service（固定规则，仅供参考）
⑦ 知识库(3): query_knowledge_base / remember_knowledge / record_diagnosis
⑧ execute(1): 任意 shell 命令

## 知识库使用（重要）
你有知识库（SQLite），它能帮你回忆过去的故障和已知的服务器信息：
- **排障前** → 先调 query_knowledge_base_tool 查一下有没有类似历史
- **排障后** → 调 record_diagnosis_tool 记录本次排障过程
- **学到新知识** → 调 remember_knowledge_tool 保存经验
这样下次遇到同样问题你就能直接参考了。

## 核心流程
第1步：查知识库 → 了解历史
第2步：快速扫描 → 用基础工具了解当前状态
第3步：你自己分析 → 综合数据 + 经验，判断问题根源
第4步：提炼输出 → 先结论，再证据，再建议
第5步：保存经验 → 调 record_diagnosis_tool 保存

## 输出风格
- 先给结论（一句话说清楚问题）
- 再给证据（关键数据，不要全贴）
- 最后给建议（可执行的操作步骤）
- 严重 🚨 一般 ⚠️ 正常 ✅

## 安全规则
- 不生成 .bat/.sh 脚本文件，直接用 execute 执行
- 涉及删除、修改系统文件，先警告风险再执行
- 不要生成 .bat / .sh 脚本文件，直接用 execute 工具执行命令
- 你的工作目录是 agent_sandbox/，不要随意写文件到其他目录"""

        # 8. 创建 DeepAgents 智能体
        self.agent = create_deep_agent(
            model=self.model,
            tools=self.tools,
            system_prompt=system_prompt,
            backend=self.backend,
            checkpointer=self.checkpointer,
        )
        self.agent_type = "DeepAgents SRE 智能体（含Shell执行）"

    def get_info(self) -> Dict[str, Any]:
        """获取智能体信息"""
        return {
            "agent_type": self.agent_type,
            "tools_count": len(self.tools) if hasattr(self, 'tools') else 0,
            "tool_names": [tool.name for tool in self.tools] if hasattr(self, 'tools') else [],
            "has_agent": self.agent is not None,
            "has_memory": self.checkpointer is not None,
            "has_shell": self.backend is not None,
            "thread_id": self.thread_id,
            "initialized": self._initialized,
        }

    def ask(self, question: str, use_thread_id: Optional[str] = None) -> str:
        """使用 DeepAgents 智能体处理用户问题"""
        if not self._initialized:
            return "智能体未初始化，请先初始化智能体"

        thread_id = use_thread_id if use_thread_id else self.thread_id

        try:
            config = {"configurable": {"thread_id": thread_id}}
            result = self.agent.invoke(
                {"messages": [HumanMessage(content=question)]},
                config=config
            )

            # 提取 AI 回复
            if isinstance(result, dict) and "messages" in result:
                messages = result["messages"]
                for msg in reversed(messages):
                    if isinstance(msg, AIMessage):
                        return msg.content

            return str(result)

        except Exception as e:
            error_msg = f"处理问题时发生错误: {str(e)}"
            print(f"[ERROR] {error_msg}")
            return f"{error_msg}\n\n请重试或检查系统配置。"

    def get_conversation_history(self, thread_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """获取对话历史"""
        if not self.checkpointer:
            return []
        thread_id = thread_id if thread_id else self.thread_id
        try:
            checkpoint = self.checkpointer.get({"configurable": {"thread_id": thread_id}})
            if checkpoint and "channel" in checkpoint:
                history = []
                for message in checkpoint["channel"]:
                    if hasattr(message, "content"):
                        history.append({
                            "role": type(message).__name__.replace("Message", "").lower(),
                            "content": message.content,
                        })
                return history
        except Exception as e:
            print(f"[WARNING] 获取对话历史失败: {e}")
        return []

    def clear_conversation_history(self, thread_id: Optional[str] = None):
        """清除对话历史"""
        print("[INFO] 清除对话历史需要完整 LangGraph 集成")
        return "对话历史清除功能需要完整 LangGraph 集成"


# ──────────────────────────────────────────
# 便捷函数
# ──────────────────────────────────────────
def ask_agent(question: str, show_init_info: bool = False, thread_id: Optional[str] = None) -> str:
    """便捷函数：使用智能体回答问题"""
    agent = OpsAgent(show_init_info=show_init_info)
    return agent.ask(question, use_thread_id=thread_id)


def test_agent():
    """测试 DeepAgents 智能体"""
    print("=" * 60)
    print("测试 DeepAgents 智能运维助手")
    print("=" * 60)
    
    agent = OpsAgent(show_init_info=False)
    
    info = agent.get_info()
    print(f"智能体类型: {info['agent_type']}")
    print(f"工具数量: {info['tools_count']}")
    print(f"工具名称: {info['tool_names']}")
    print(f"支持Shell执行: {info['has_shell']}")
    print(f"支持对话记忆: {info['has_memory']}")
    
    queries = [
        "CPU使用率是多少？",
        "内存使用情况怎么样？",
        "请检查nginx服务状态",
        "显示系统信息",
        "分析系统健康状况"
    ]
    
    for i, query in enumerate(queries, 1):
        print(f"\n[{i}] 问题: {query}")
        try:
            response = agent.ask(query)
            print(f"回答: {response[:150]}..." if len(response) > 150 else f"回答: {response}")
        except Exception as e:
            print(f"错误: {e}")
    
    print("\n" + "=" * 60)
    print("测试完成！")
    return True


if __name__ == "__main__":
    test_agent()
