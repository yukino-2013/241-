#!/usr/bin/env python3
"""
智能运维助手 - 知识库模块
SQLite 存储：服务器基线 + 诊断历史 + 经验记录
AI 可自动查询和新增知识
"""

import os
import json
import sqlite3
import time
import threading
from typing import Dict, Any, List, Optional
from pathlib import Path

# 数据库路径
DB_DIR = Path(__file__).resolve().parent
DB_PATH = DB_DIR / "knowledge.db"
_AUTO_INIT_DONE = False
_init_lock = threading.Lock()


# ──────────────────────────────────────────
# 数据库初始化
# ──────────────────────────────────────────

def _get_conn() -> sqlite3.Connection:
    """获取数据库连接（线程安全）"""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")  # 写并发优化
    return conn


def init_kb():
    """初始化知识库表结构（幂等）"""
    global _AUTO_INIT_DONE
    if _AUTO_INIT_DONE:
        return
    with _init_lock:
        if _AUTO_INIT_DONE:
            return
        conn = _get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS baselines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric TEXT NOT NULL,
                value TEXT NOT NULL,
                unit TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                recorded_at TEXT DEFAULT (datetime('now','localtime'))
            );

            CREATE TABLE IF NOT EXISTS diagnoses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symptom TEXT NOT NULL,
                diagnosis TEXT NOT NULL,
                resolution TEXT DEFAULT '',
                service TEXT DEFAULT '',
                severity TEXT DEFAULT 'info',
                created_at TEXT DEFAULT (datetime('now','localtime'))
            );

            CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                content TEXT NOT NULL,
                tags TEXT DEFAULT '',
                created_at TEXT DEFAULT (datetime('now','localtime'))
            );

            CREATE INDEX IF NOT EXISTS idx_baselines_metric ON baselines(metric);
            CREATE INDEX IF NOT EXISTS idx_diagnoses_symptom ON diagnoses(symptom);
            CREATE INDEX IF NOT EXISTS idx_knowledge_topic ON knowledge(topic);
        """)
        conn.commit()
        conn.close()
        _AUTO_INIT_DONE = True


# ──────────────────────────────────────────
# 基线管理
# ──────────────────────────────────────────

def record_baseline(metric: str, value: str, unit: str = "", notes: str = "") -> Dict:
    """记录一条服务器基线数据"""
    init_kb()
    conn = _get_conn()
    conn.execute(
        "INSERT INTO baselines (metric, value, unit, notes) VALUES (?, ?, ?, ?)",
        (metric, value, unit, notes)
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return {"id": row_id, "metric": metric, "value": value}


def get_baseline(metric: str) -> Optional[Dict]:
    """获取某个指标的最新基线"""
    init_kb()
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM baselines WHERE metric = ? ORDER BY recorded_at DESC LIMIT 1",
        (metric,)
    ).fetchone()
    conn.close()
    if row:
        return dict(row)
    return None


def get_all_baselines() -> List[Dict]:
    """获取所有基线数据"""
    init_kb()
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM baselines WHERE id IN (SELECT MAX(id) FROM baselines GROUP BY metric)"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def auto_capture_baselines() -> int:
    """
    自动采集当前系统状态作为基线
    返回: 新增基线条目数
    """
    count = 0
    try:
        import psutil
        # CPU 正常范围（空闲时）
        cpu_idle = psutil.cpu_percent(interval=1)
        record_baseline("cpu_idle_percent", f"{cpu_idle:.1f}", "%", "系统空闲时CPU使用率")
        count += 1

        # 内存基线
        mem = psutil.virtual_memory()
        record_baseline("memory_total_gb", f"{mem.total / (1024**3):.1f}", "GB", "物理内存总量")
        record_baseline("memory_available_gb", f"{mem.available / (1024**3):.1f}", "GB", "可用内存")
        count += 2

        # 磁盘基线
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                record_baseline(
                    f"disk_{part.mountpoint.replace('/','_').replace(':','')}_percent",
                    f"{usage.percent:.1f}", "%", f"{part.mountpoint} 磁盘使用率"
                )
                count += 1
            except:
                continue

    except Exception as e:
        print(f"[WARN] 自动采集基线失败: {e}")

    return count


# ──────────────────────────────────────────
# 诊断记录管理
# ──────────────────────────────────────────

def store_diagnosis(
    symptom: str,
    diagnosis: str,
    resolution: str = "",
    service: str = "",
    severity: str = "info"
) -> Dict:
    """保存一条诊断记录"""
    init_kb()
    conn = _get_conn()
    conn.execute(
        "INSERT INTO diagnoses (symptom, diagnosis, resolution, service, severity) VALUES (?, ?, ?, ?, ?)",
        (symptom, diagnosis, resolution, service, severity)
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return {"id": row_id, "symptom": symptom}


def get_recent_diagnoses(limit: int = 10) -> List[Dict]:
    """获取最近的诊断记录"""
    init_kb()
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM diagnoses ORDER BY created_at DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ──────────────────────────────────────────
# 知识条目管理
# ──────────────────────────────────────────

def add_knowledge(topic: str, content: str, tags: str = "") -> Dict:
    """添加一条知识条目"""
    init_kb()
    conn = _get_conn()
    conn.execute(
        "INSERT INTO knowledge (topic, content, tags) VALUES (?, ?, ?)",
        (topic, content, tags)
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return {"id": row_id, "topic": topic}


# ──────────────────────────────────────────
# 综合查询
# ──────────────────────────────────────────

def query_knowledge(query_text: str, limit: int = 5) -> Dict[str, Any]:
    """
    综合查询知识库——搜索基线和历史诊断
    参数: query_text - 问题症状或关键词
    返回: {baselines, diagnoses, knowledge} 三个来源的匹配结果
    """
    init_kb()
    result = {"baselines": [], "diagnoses": [], "knowledge": []}

    conn = _get_conn()

    # 1. 搜索诊断记录（按症状匹配）
    rows = conn.execute(
        "SELECT * FROM diagnoses WHERE symptom LIKE ? OR diagnosis LIKE ? ORDER BY created_at DESC LIMIT ?",
        (f"%{query_text}%", f"%{query_text}%", limit)
    ).fetchall()
    result["diagnoses"] = [dict(r) for r in rows]

    # 2. 搜索知识条目
    rows = conn.execute(
        "SELECT * FROM knowledge WHERE topic LIKE ? OR content LIKE ? OR tags LIKE ? ORDER BY created_at DESC LIMIT ?",
        (f"%{query_text}%", f"%{query_text}%", f"%{query_text}%", limit)
    ).fetchall()
    result["knowledge"] = [dict(r) for r in rows]

    # 3. 返回所有基线（作为参考上下文）
    rows = conn.execute(
        "SELECT * FROM baselines WHERE id IN (SELECT MAX(id) FROM baselines GROUP BY metric)"
    ).fetchall()
    result["baselines"] = [dict(r) for r in rows]

    conn.close()
    return result


# ──────────────────────────────────────────
# 便捷初始化
# ──────────────────────────────────────────

def ensure_kb_ready():
    """确保知识库已初始化，并采集基线（只在第一次调用时执行）"""
    init_kb()
    # 检查是否已有基线数据
    conn = _get_conn()
    count = conn.execute("SELECT COUNT(*) FROM baselines").fetchone()[0]
    conn.close()
    if count == 0:
        auto_capture_baselines()


# ──────────────────────────────────────────
# 测试
# ──────────────────────────────────────────

def test_kb():
    """测试知识库功能"""
    # 重置测试
    global _AUTO_INIT_DONE
    _AUTO_INIT_DONE = False

    print("=" * 60)
    print("测试知识库模块")
    print("=" * 60)

    # 1. 初始化
    init_kb()
    print("\n[OK] 知识库初始化完成")

    # 2. 自动采集基线
    count = auto_capture_baselines()
    print(f"[OK] 自动采集基线: {count} 条")

    # 3. 查询基线
    cpu_base = get_baseline("cpu_idle_percent")
    print(f"[OK] CPU基线: {cpu_base}")

    # 4. 存储诊断记录
    store_diagnosis(
        symptom="CPU 高",
        diagnosis="nginx占用85%CPU，237个连接",
        resolution="重启nginx后恢复正常",
        service="nginx",
        severity="critical"
    )
    print("[OK] 诊断记录已保存")

    # 5. 添加知识
    add_knowledge(
        topic="nginx CPU 高排查",
        content="1.检查连接数 netstat -an | grep :80 | wc -l\n2.检查配置 nginx -t\n3.查看日志 tail -100 /var/log/nginx/error.log",
        tags="nginx, CPU, 排障"
    )
    print("[OK] 知识条目已添加")

    # 6. 综合查询
    result = query_knowledge("CPU")
    print(f"\n[OK] 查询 'CPU' 结果:")
    print(f"  基线: {len(result['baselines'])} 条")
    print(f"  诊断记录: {len(result['diagnoses'])} 条")
    for d in result['diagnoses']:
        print(f"    - {d['symptom']}: {d['diagnosis'][:40]}...")
    print(f"  知识: {len(result['knowledge'])} 条")

    # 7. 最近诊断
    recent = get_recent_diagnoses(5)
    print(f"\n[OK] 最近诊断: {len(recent)} 条")

    # 清除测试数据
    conn = _get_conn()
    conn.execute("DELETE FROM diagnoses")
    conn.execute("DELETE FROM knowledge")
    conn.execute("DELETE FROM baselines")
    conn.commit()
    conn.close()
    _AUTO_INIT_DONE = False

    print("\n" + "=" * 60)
    print("测试通过！")
    return True


if __name__ == "__main__":
    test_kb()
    # 清理测试数据库
    if DB_PATH.exists():
        os.remove(str(DB_PATH))
